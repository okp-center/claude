================================================================================
 CentrApp - восстановленные исходники из tc.gt.okpcenter-Signed.apk
================================================================================

ЧТО ЭТО
-------
Полный C#-проект .NET MAUI приложения «Центр», восстановленный из твоего APK.

  package      tc.gt.okpcenter
  сайт         https://okp-center.gt.tc
  название     Центр
  versionName  1.0   (versionCode 1)
  minSdk 21 / targetSdk 35 / compileSdk 35
  сборка       .NET 9 + MAUI, Release, AOT + trimming

ГЛАВНОЕ: ЭТО ВОССТАНОВЛЕНО ИЗ НАСТОЯЩЕГО IL, А НЕ ПРИДУМАНО
------------------------------------------------------------
В архиве лежит папка _evidence/ — там сырой дизассемблерный листинг (1295 строк),
список типов/методов и сама CentrApp.dll. Можешь сверить строчка в строчку.

КАК ЭТО БЫЛО СДЕЛАНО (почему в этот раз получилось)
--------------------------------------------------------
1. APK распакован как ZIP.
2. В MAUI-приложениях .NET-сборок НЕТ отдельными файлами (в assemblies/ пусто).
   Они упакованы в assembly store:
       lib/arm64-v8a/libassemblies.arm64-v8a.blob.so
   Каждая сборка внутри сжата LZ4 с заголовком "XALZ".
   Этот формат разобран вручную -> распаковано 90 сборок.
3. Из них взята CentrApp.dll (19 968 байт) — это твой код.
4. Написан разборщик метаданных ECMA-335 + дизассемблер IL:
   таблицы TypeDef / MethodDef / Field / Param / CustomAttribute / Constant /
   AssemblyRef / MemberRef / TypeRef, пул строк #US, сигнатуры, EH-блоки (try/catch).
5. По IL восстановлен C#.

СТАТИСТИКА ПОЛНОТЫ (главное число)
---------------------------------
   типов в CentrApp.dll ............ 18
   методов ....................... 53
   из них с телом IL ............. 53
   абстрактных / без тела ....... 0

То есть НИ ОДНОГО метода не потеряно. Всё, что было в APK, лежит в этом архиве.

ПОЧЕМУ ПРОШЛЫЙ РАЗ КОДА БЫЛО МЕНЬШЕ
-------------------------------------------
Прошлый результат не был получен из IL — он был воссоздан из общих соображений,
поэтому часть методов просто не попала в вывод. Сейчас источник — байты из APK.

И второе, важное: само приложение действительно МАЛЕНЬКОЕ. Это оболочка-WebView
над сайтом okp-center.gt.tc + пуш-уведомления + выбор файлов + камера/микрофон.
Вся логика мессенджера (чаты, авторизация, сообщения) живёт НА САЙТЕ, а не в apk.
Если ты искал в коде приложения функции чатов — их там никогда и не было.

СТРУКТУРА ПРОЕКТА
-----------------
CentrApp/
  CentrApp.csproj
  App.xaml  App.xaml.cs
  MainPage.xaml  MainPage.xaml.cs
  MauiProgram.cs
  Resources/Raw/offline.html          <- вытащен из APK байт-в-байт
  Resources/AppIcon/appicon.png       <- вытащен из APK (растр, оригинал был .svg)
  Resources/Splash/splash.png         <- вытащен из APK
  Platforms/Android/
    AndroidManifest.xml
    google-services.json              <- собран из resources.arsc
    MainActivity.cs
    MainApplication.cs
    CentrWeb.cs
    CentrWebViewClient.cs
    CentrWebChromeClient.cs
    FileChooserBridge.cs
    PushManager.cs
    CentrFirebaseMessagingService.cs
    TokenCompleteListener.cs
    Resources/drawable/ic_notification.xml
  Platforms/Windows/App.xaml          <- найден в managed resources, байт-в-байт

ЧТО ДЕЛАЕТ КАЖДЫЙ ФАЙЛ
-------------------------
MauiProgram.cs
    Настраивает Android WebView через WebViewHandler.Mapper (ключ "CentrAndroidWebView"):
    JavaScript, DOM storage, database, автовоспроизведение медиа без жеста,
    доступ к файлам/content, множественные окна, свои WebViewClient и WebChromeClient.

MainPage.xaml.cs
    SiteUrl = https://okp-center.gt.tc
    При появлении один раз грузит сайт; если сети нет — показывает offline.html
    из пакета; как только сеть вернулась (Connectivity.ConnectivityChanged) — сам возвращается на сайт.

MainActivity.cs
    Firebase init -> канал уведомлений -> запрос разрешений (микрофон, камера,
    с Android 13 ещё POST_NOTIFICATIONS, requestCode 1001) -> запрос FCM-токена.
    Кнопка "назад" сначала идёт назад по истории WebView.

CentrWebViewClient.cs
    Ссылки на okp-center.gt.tc открываются внутри, всё остальное (и mailto:, tel:,
    intent: и т.п.) — во внешнем приложении. Ошибка главного фрейма -> offline.html.

CentrWebChromeClient.cs
    Разрешает запросы камеры/микрофона со страницы, выбор файлов (<input type=file>),
    target=_blank открывает во внешнем браузере.

FileChooserBridge.cs
    RequestCode = 51426. Мост между WebChromeClient.OnShowFileChooser и OnActivityResult.

PushManager.cs
    Канал "centr_messages" («Сообщения Центр», importance High, вибрация).
    Токен отдаётся в сайт через JS:
        window.centrOnPushToken('<token>','android')
    ↑ вот это самое важное для связки с сайтом — на стороне сайта должна быть
      функция window.centrOnPushToken.
    Уведомление кладёт в Intent доп. поле "centr_url".

CentrFirebaseMessagingService.cs
    Берёт title/body из notification, если пусто — из data["title"] / data["body"],
    ссылка — из data["url"].

ЧЕГО В АРХИВЕ НЕТ И ПОЧЕМУ (честно)
---------------------------------------
1. MainPage.xaml.g.cs / App.xaml.g.cs (метод InitializeComponent) — их генерирует SDK
   из .xaml при сборке. Они и в твоём исходном проекте не лежали файлами.
   Содержимое .xaml восстановлено из IL метода InitializeComponent точно
   (цвет #111B21, Shell.NavBarIsVisible=False, WebView x:Name="Web", Fill/Fill).
2. Resource.designer.cs — генерится SDK.
3. Оригинальные .svg иконки — в APK они уже растризованы в png, вектор не восстановить.
   Подставлены png из APK — соберётся, но лучше верни свои .svg если найдёшь.
4. Комментарии, имена локальных переменных, порядок using и форматирование —
   в IL их физически нет. Логика совпадает 1:1, текст файла — не побайтово.
5. Названия параметров методов взяты из таблицы Param — тут они настоящие.

КАК СОБРАТЬ
------------
    dotnet workload install maui-android
    cd CentrApp
    dotnet restore
    dotnet build -c Debug -f net9.0-android

Собрать релизный apk как был:
    dotnet publish -c Release -f net9.0-android \
        -p:AndroidKeyStore=true \
        -p:AndroidSigningKeyStore=my.keystore \
        -p:AndroidSigningKeyAlias=<alias> \
        -p:AndroidSigningKeyPass=<pass> \
        -p:AndroidSigningStorePass=<pass>

ВАЖНО ПРО ПОДПИСЬ: если хочешь обновлять уже установленное приложение поверх —
нужен ТОТ ЖЕ keystore. Из APK ключ достать нельзя (там только публичный сертификат).
Нет старого keystore -> только установка с нуля (с удалением старой версии).

ПРОВЕРЬ МЕНЯ САМ (стоит сделать)
-------------------------------
В _evidence/assemblies/CentrApp.dll лежит та самая сборка. Открой её в:
  - ILSpy      https://github.com/icsharpcode/ILSpy   (есть и ilspycmd для консоли)
  - dnSpyEx    https://github.com/dnSpyEx/dnSpy
  - JetBrains dotPeek
И сравни с тем, что в этом архиве. Должно совпасть по смыслу полностью.

Быстрая команда:
    dotnet tool install -g ilspycmd
    ilspycmd -p -o ./ilspy-out _evidence/assemblies/CentrApp.dll

СОДЕРЖИМОЕ _evidence/
--------------------
  assemblies/CentrApp.dll        твоя сборка, распакованная из assembly store
  assemblies/_Microsoft.Android.Resource.Designer.dll
  disassembly.txt                полный IL-листинг всех 53 методов
  types_and_methods.txt          список типов, полей, сигнатур, атрибутов
  strings.txt                    все 29 строковых литералов из пула #US
  AndroidManifest.decoded.xml    расшифрованный бинарный манифест из APK
  tools/                         скрипты, которыми всё это сделано (python3)

БОНУС: КАК ПРАВИЛЬНО ПИСАТЬ "ВООБЩЕМ"
---------------------------------------------
Слова «вообщем» в русском языке НЕТ. Есть два разных слова:
   «в общем»  (раздельно) — если подводишь итог: «В общем, всё готово»
   «вообще»   (слитно)    — в значении «совсем / в целом»: «Он вообще не пришёл»
Смешение этих двух и дало несуществующее «вообщем».
