#!/usr/bin/env python3
"""Extract .NET assemblies from a .NET-for-Android assembly store blob (.so).

Handles XALZ (LZ4-compressed) and raw PE entries. Names each output file from
the assembly's own CLI metadata Module table.
"""
import os
import struct
import sys

import lz4.block


def _sections(buf):
    if buf[:2] != b"MZ":
        return None
    e_lfanew = struct.unpack_from("<I", buf, 0x3C)[0]
    if buf[e_lfanew:e_lfanew + 4] != b"PE\0\0":
        return None
    coff = e_lfanew + 4
    num_sections = struct.unpack_from("<H", buf, coff + 2)[0]
    size_opt = struct.unpack_from("<H", buf, coff + 16)[0]
    opt = coff + 20
    magic = struct.unpack_from("<H", buf, opt)[0]
    if magic == 0x10B:
        dd = opt + 96
    elif magic == 0x20B:
        dd = opt + 112
    else:
        return None
    sec_off = opt + size_opt
    secs = []
    for i in range(num_sections):
        s = sec_off + i * 40
        vsize, vaddr, rsize, praw = struct.unpack_from("<IIII", buf, s + 8)
        secs.append((vaddr, vsize, praw, rsize))
    return dd, secs


def pe_size(buf):
    info = _sections(buf)
    if not info:
        return len(buf)
    _, secs = info
    end = 0
    for (_vaddr, _vsize, praw, rsize) in secs:
        end = max(end, praw + rsize)
    return end if 0 < end <= len(buf) else len(buf)


def rva_to_off(rva, secs):
    for (vaddr, vsize, praw, rsize) in secs:
        if vaddr <= rva < vaddr + max(vsize, rsize):
            return praw + (rva - vaddr)
    return None


def module_name(buf):
    """Read the Module table's Name (e.g. 'MyApp.dll') from CLI metadata."""
    try:
        info = _sections(buf)
        if not info:
            return None
        dd, secs = info
        cli_rva = struct.unpack_from("<I", buf, dd + 14 * 8)[0]
        if not cli_rva:
            return None
        cli_off = rva_to_off(cli_rva, secs)
        if cli_off is None:
            return None
        md_rva = struct.unpack_from("<I", buf, cli_off + 8)[0]
        md_off = rva_to_off(md_rva, secs)
        if md_off is None or buf[md_off:md_off + 4] != b"BSJB":
            return None
        ver_len = struct.unpack_from("<I", buf, md_off + 12)[0]
        p = md_off + 16 + ver_len + 2
        nstreams = struct.unpack_from("<H", buf, p)[0]
        p += 2
        streams = {}
        for _ in range(nstreams):
            soff, ssize = struct.unpack_from("<II", buf, p)
            p += 8
            e = buf.index(b"\0", p)
            streams[buf[p:e].decode("ascii", "replace")] = (md_off + soff, ssize)
            p = (e + 1 + 3) & ~3
        tbl = "#~" if "#~" in streams else ("#-" if "#-" in streams else None)
        if not tbl or "#Strings" not in streams:
            return None
        toff = streams[tbl][0]
        stroff = streams["#Strings"][0]
        heap_sizes = buf[toff + 6]
        valid = struct.unpack_from("<Q", buf, toff + 8)[0]
        q = toff + 24
        rows = {}
        for i in range(64):
            if (valid >> i) & 1:
                rows[i] = struct.unpack_from("<I", buf, q)[0]
                q += 4
        if rows.get(0, 0) < 1:
            return None
        wide_str = bool(heap_sizes & 1)
        mp = q + 2  # skip Generation (uint16)
        nidx = struct.unpack_from("<I" if wide_str else "<H", buf, mp)[0]
        e = buf.index(b"\0", stroff + nidx)
        return buf[stroff + nidx:e].decode("utf-8", "replace")
    except Exception:
        return None


def candidates(data):
    out = []
    i = 0
    while True:
        j = data.find(b"XALZ", i)
        if j < 0:
            break
        out.append(j)
        i = j + 4
    i = 0
    while True:
        j = data.find(b"MZ", i)
        if j < 0:
            break
        try:
            e = struct.unpack_from("<I", data, j + 0x3C)[0]
            if 0 < e < 0x400 and data[j + e:j + e + 4] == b"PE\0\0":
                out.append(j)
        except Exception:
            pass
        i = j + 2
    return sorted(set(out))


def extract(blob_path, outdir):
    data = open(blob_path, "rb").read()
    print("blob: %s (%d bytes)" % (os.path.basename(blob_path), len(data)))
    xaba = data.find(b"XABA")
    print("  XABA store header at: %s" % xaba)
    if xaba >= 0:
        print("  store hdr: %s" % data[xaba:xaba + 32].hex())
    cands = candidates(data)
    print("  entry candidates: %d" % len(cands))
    os.makedirs(outdir, exist_ok=True)
    saved, failed, skipped = [], 0, 0
    for k, off in enumerate(cands):
        end = cands[k + 1] if k + 1 < len(cands) else len(data)
        chunk = data[off:end]
        if chunk[:4] == b"XALZ":
            try:
                _idx, usize = struct.unpack_from("<II", chunk, 4)
                raw = lz4.block.decompress(chunk[12:], uncompressed_size=usize)
            except Exception as ex:
                failed += 1
                print("  ! XALZ@%d failed: %s" % (off, ex))
                continue
        else:
            raw = chunk[:pe_size(chunk)]
        name = module_name(raw)
        if not name:
            skipped += 1
            continue
        if not name.lower().endswith(".dll"):
            name += ".dll"
        name = os.path.basename(name)
        with open(os.path.join(outdir, name), "wb") as f:
            f.write(raw)
        saved.append((name, len(raw)))
    print("  saved=%d failed=%d skipped=%d" % (len(saved), failed, skipped))
    return saved


if __name__ == "__main__":
    blob, outdir = sys.argv[1], sys.argv[2]
    got = extract(blob, outdir)
    for name, size in sorted(got, key=lambda t: -t[1]):
        print("%10d  %s" % (size, name))
