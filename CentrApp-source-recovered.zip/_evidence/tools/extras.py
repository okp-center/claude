#!/usr/bin/env python3
"""Extra recovery: assembly refs, resource-id lookup, binary AndroidManifest decode."""
import struct
import sys

sys.path.insert(0, "/data/apk")
from disasm import Meta  # noqa: E402


def assembly_refs(path):
    m = Meta(open(path, "rb").read())
    out = []
    for i in range(1, m.nrows(0x23) + 1):
        r = m.row(0x23, i)
        out.append((m.s(r[6]), "%d.%d.%d.%d" % (r[0], r[1], r[2], r[3])))
    return out


def find_resource_const(path, target):
    """Find field name whose constant value == target (Constant table 0x0B)."""
    m = Meta(open(path, "rb").read())
    hits = []
    for i in range(1, m.nrows(0x0B) + 1):
        r = m.row(0x0B, i)
        ctype, parent, val = r[0], r[2], r[3]
        tb, idx = m.decode_coded("HasConstant", parent)
        if tb != 0x04:
            continue
        b = m.blob(val)
        if ctype == 0x08 and len(b) >= 4:
            v = struct.unpack_from("<i", b, 0)[0]
            if v == target:
                fr = m.row(0x04, idx)
                hits.append((m.owner_of_field(idx), m.s(fr[1]), v))
    return hits


# ---------------- binary AndroidManifest (AXML) ----------------
def axml(path):
    d = open(path, "rb").read()
    pos = 8
    strings = []
    res_ids = []
    lines = []
    ns_map = {}

    def s(i):
        return strings[i] if 0 <= i < len(strings) else ""

    while pos < len(d):
        ctype, hsize, csize = struct.unpack_from("<HHI", d, pos)
        if csize <= 0:
            break
        if ctype == 0x0001:  # string pool
            scount, stycount, flags, sstart, systart = struct.unpack_from("<IIIII", d, pos + 8)
            utf8 = bool(flags & 0x100)
            offs = struct.unpack_from("<%dI" % scount, d, pos + 28)
            base = pos + sstart
            for o in offs:
                p = base + o
                if utf8:
                    n1 = d[p]
                    p += 2 if n1 < 0x80 else 3
                    ln = d[p - 1]
                    strings.append(d[p:p + ln].decode("utf-8", "replace"))
                else:
                    ln = struct.unpack_from("<H", d, p)[0]
                    strings.append(d[p + 2:p + 2 + ln * 2].decode("utf-16-le", "replace"))
        elif ctype == 0x0180:
            n = (csize - hsize) // 4
            res_ids = list(struct.unpack_from("<%dI" % n, d, pos + hsize))
        elif ctype == 0x0100:
            p = pos + hsize
            pfx, uri = struct.unpack_from("<II", d, p)
            ns_map[s(uri)] = s(pfx)
        elif ctype == 0x0102:
            p = pos + hsize
            ns, name, astart, asize, acount = struct.unpack_from("<IIHHH", d, p)
            ap = p + astart
            attrs = []
            for k in range(acount):
                q = ap + k * 20
                ans, aname, araw, tv, data = struct.unpack_from("<IIIII", d, q)
                dtype = (tv >> 24) & 0xFF
                pfx = ns_map.get(s(ans), "")
                key = (pfx + ":" if pfx else "") + s(aname)
                if dtype == 0x03:
                    val = s(data)
                elif dtype == 0x12:
                    val = "true" if data else "false"
                elif dtype == 0x10:
                    val = str(struct.unpack("<i", struct.pack("<I", data))[0])
                elif dtype == 0x11:
                    val = "0x%08x" % data
                elif dtype == 0x01:
                    val = "@0x%08x" % data
                else:
                    val = s(araw) if araw != 0xFFFFFFFF else "0x%08x" % data
                attrs.append('%s="%s"' % (key, val))
            lines.append("<%s %s>" % (s(name), " ".join(attrs)))
        elif ctype == 0x0103:
            p = pos + hsize
            ns, name = struct.unpack_from("<II", d, p)
            lines.append("</%s>" % s(name))
        pos += csize
    return lines


if __name__ == "__main__":
    print("===== ASSEMBLY REFERENCES (CentrApp.dll) =====")
    for n, v in assembly_refs("/data/apk/out/assemblies/CentrApp.dll"):
        print("  %-55s %s" % (n, v))

    print("\n===== RESOURCE ID 2131165356 =====")
    for owner, fname, v in find_resource_const("/data/apk/out/assemblies/_Microsoft.Android.Resource.Designer.dll", 2131165356):
        print("  %s.%s = %d" % (owner, fname, v))

    print("\n===== ANDROID MANIFEST =====")
    for ln in axml("/data/apk/x/AndroidManifest.xml"):
        print(ln)
