#!/usr/bin/env python3
"""Full CLI metadata reader + IL disassembler (ECMA-335), pure Python."""
import os
import struct
import sys


def sections_and_dd(buf):
    e = struct.unpack_from("<I", buf, 0x3C)[0]
    coff = e + 4
    ns = struct.unpack_from("<H", buf, coff + 2)[0]
    so = struct.unpack_from("<H", buf, coff + 16)[0]
    opt = coff + 20
    magic = struct.unpack_from("<H", buf, opt)[0]
    dd = opt + (96 if magic == 0x10B else 112)
    secs = []
    for i in range(ns):
        s = opt + so + i * 40
        vsize, vaddr, rsize, praw = struct.unpack_from("<IIII", buf, s + 8)
        secs.append((vaddr, vsize, praw, rsize))
    return dd, secs


def rva_to_off(rva, secs):
    for (va, vs, pr, rs) in secs:
        if va <= rva < va + max(vs, rs):
            return pr + (rva - va)
    return None


CODED = {
    "TypeDefOrRef": ([0x02, 0x01, 0x1B], 2),
    "HasConstant": ([0x04, 0x08, 0x17], 2),
    "HasCustomAttribute": ([0x06, 0x04, 0x01, 0x02, 0x08, 0x09, 0x0A, 0x11, 0x1A, 0x1B, 0x14, 0x17, 0x20, 0x23, 0x26, 0x27, 0x28, 0x2A], 5),
    "HasFieldMarshal": ([0x04, 0x08], 1),
    "HasDeclSecurity": ([0x02, 0x06, 0x20], 2),
    "MemberRefParent": ([0x02, 0x01, 0x1A, 0x06, 0x1B], 3),
    "HasSemantics": ([0x14, 0x17], 1),
    "MethodDefOrRef": ([0x06, 0x0A], 1),
    "MemberForwarded": ([0x04, 0x06], 1),
    "Implementation": ([0x26, 0x23, 0x27], 2),
    "CustomAttributeType": ([0, 0, 0x06, 0x0A, 0], 3),
    "ResolutionScope": ([0x00, 0x1A, 0x23, 0x01], 2),
    "TypeOrMethodDef": ([0x02, 0x06], 1),
}

T = lambda n: ("idx", n)
C = lambda n: ("coded", n)

SCHEMA = {
    0x00: ["u2", "S", "G", "G", "G"],
    0x01: [C("ResolutionScope"), "S", "S"],
    0x02: ["u4", "S", "S", C("TypeDefOrRef"), T(0x04), T(0x06)],
    0x03: [T(0x04)],
    0x04: ["u2", "S", "B"],
    0x05: [T(0x06)],
    0x06: ["u4", "u2", "u2", "S", "B", T(0x08)],
    0x07: [T(0x08)],
    0x08: ["u2", "u2", "S"],
    0x09: [T(0x02), C("TypeDefOrRef")],
    0x0A: [C("MemberRefParent"), "S", "B"],
    0x0B: ["u1", "u1", C("HasConstant"), "B"],
    0x0C: [C("HasCustomAttribute"), C("CustomAttributeType"), "B"],
    0x0D: [C("HasFieldMarshal"), "B"],
    0x0E: ["u2", C("HasDeclSecurity"), "B"],
    0x0F: ["u2", "u4", T(0x02)],
    0x10: ["u4", T(0x04)],
    0x11: ["B"],
    0x12: [T(0x02), T(0x14)],
    0x13: [T(0x14)],
    0x14: ["u2", "S", C("TypeDefOrRef")],
    0x15: [T(0x02), T(0x17)],
    0x16: [T(0x17)],
    0x17: ["u2", "S", "B"],
    0x18: ["u2", T(0x06), C("HasSemantics")],
    0x19: [T(0x02), C("MethodDefOrRef"), C("MethodDefOrRef")],
    0x1A: ["S"],
    0x1B: ["B"],
    0x1C: ["u2", C("MemberForwarded"), "S", T(0x1A)],
    0x1D: ["u4", T(0x04)],
    0x1E: ["u4", "u4"],
    0x1F: ["u4"],
    0x20: ["u4", "u2", "u2", "u2", "u2", "u4", "B", "S", "S"],
    0x21: ["u4"],
    0x22: ["u4", "u4", "u4"],
    0x23: ["u2", "u2", "u2", "u2", "u4", "B", "S", "S", "B"],
    0x24: ["u4", T(0x23)],
    0x25: ["u4", "u4", "u4", T(0x23)],
    0x26: ["u4", "S", "B"],
    0x27: ["u4", "u4", "S", "S", C("Implementation")],
    0x28: ["u4", "u4", "S", C("Implementation")],
    0x29: [T(0x02), T(0x02)],
    0x2A: ["u2", "u2", C("TypeOrMethodDef"), "S"],
    0x2B: [C("MethodDefOrRef"), "B"],
    0x2C: [T(0x2A), C("TypeDefOrRef")],
}


class Meta:
    def __init__(self, buf):
        self.buf = buf
        dd, secs = sections_and_dd(buf)
        self.secs = secs
        cli = rva_to_off(struct.unpack_from("<I", buf, dd + 14 * 8)[0], secs)
        md = rva_to_off(struct.unpack_from("<I", buf, cli + 8)[0], secs)
        self.res_rva, self.res_size = struct.unpack_from("<II", buf, cli + 24)
        vl = struct.unpack_from("<I", buf, md + 12)[0]
        p = md + 16 + vl + 2
        n = struct.unpack_from("<H", buf, p)[0]
        p += 2
        self.streams = {}
        for _ in range(n):
            so, ss = struct.unpack_from("<II", buf, p)
            p += 8
            e = buf.index(b"\0", p)
            self.streams[buf[p:e].decode("ascii", "replace")] = (md + so, ss)
            p = (e + 1 + 3) & ~3
        self.stroff = self.streams.get("#Strings", (0, 0))[0]
        self.bloboff = self.streams.get("#Blob", (0, 0))[0]
        self.us = self.streams.get("#US")
        t = self.streams.get("#~") or self.streams.get("#-")
        self.hs = buf[t[0] + 6]
        valid = struct.unpack_from("<Q", buf, t[0] + 8)[0]
        q = t[0] + 24
        self.rows = {}
        for i in range(64):
            if (valid >> i) & 1:
                self.rows[i] = struct.unpack_from("<I", buf, q)[0]
                q += 4
        self.S = 4 if self.hs & 1 else 2
        self.G = 4 if self.hs & 2 else 2
        self.B = 4 if self.hs & 4 else 2
        self.start = q
        self._sizes = {}
        self._offs = {}
        off = q
        for tb in sorted(self.rows):
            self._offs[tb] = off
            off += self.rows[tb] * self.fsize(tb)

    def isize(self, tb):
        return 4 if self.rows.get(tb, 0) >= 65536 else 2

    def csize(self, nm):
        tabs, bits = CODED[nm]
        m = max((self.rows.get(x, 0) for x in tabs if x), default=0)
        return 4 if m >= (1 << (16 - bits)) else 2

    def wsize(self, f):
        if f == "u1":
            return 1
        if f == "u2":
            return 2
        if f == "u4":
            return 4
        if f == "S":
            return self.S
        if f == "G":
            return self.G
        if f == "B":
            return self.B
        if f[0] == "idx":
            return self.isize(f[1])
        return self.csize(f[1])

    def fsize(self, tb):
        if tb not in self._sizes:
            self._sizes[tb] = sum(self.wsize(f) for f in SCHEMA[tb])
        return self._sizes[tb]

    def row(self, tb, i):
        """1-based row -> list of raw values"""
        o = self._offs[tb] + (i - 1) * self.fsize(tb)
        out = []
        for f in SCHEMA[tb]:
            w = self.wsize(f)
            v = int.from_bytes(self.buf[o:o + w], "little")
            out.append(v)
            o += w
        return out

    def nrows(self, tb):
        return self.rows.get(tb, 0)

    def s(self, i):
        if not i:
            return ""
        e = self.buf.index(b"\0", self.stroff + i)
        return self.buf[self.stroff + i:e].decode("utf-8", "replace")

    def blob(self, i):
        p = self.bloboff + i
        b0 = self.buf[p]
        if (b0 & 0x80) == 0:
            ln, p = b0, p + 1
        elif (b0 & 0xC0) == 0x80:
            ln, p = ((b0 & 0x3F) << 8) | self.buf[p + 1], p + 2
        else:
            ln = ((b0 & 0x1F) << 24) | (self.buf[p + 1] << 16) | (self.buf[p + 2] << 8) | self.buf[p + 3]
            p += 4
        return self.buf[p:p + ln]

    def ustr(self, i):
        p = self.us[0] + i
        b0 = self.buf[p]
        if (b0 & 0x80) == 0:
            ln, p = b0, p + 1
        elif (b0 & 0xC0) == 0x80:
            ln, p = ((b0 & 0x3F) << 8) | self.buf[p + 1], p + 2
        else:
            ln = ((b0 & 0x1F) << 24) | (self.buf[p + 1] << 16) | (self.buf[p + 2] << 8) | self.buf[p + 3]
            p += 4
        raw = self.buf[p:p + (ln - 1 if ln % 2 else ln)]
        return raw.decode("utf-16-le", "replace")

    def decode_coded(self, nm, v):
        tabs, bits = CODED[nm]
        tag = v & ((1 << bits) - 1)
        idx = v >> bits
        tb = tabs[tag] if tag < len(tabs) else 0
        return tb, idx

    # --- names ---
    def typedef_name(self, i):
        r = self.row(0x02, i)
        ns, nm = self.s(r[2]), self.s(r[1])
        return (ns + "." + nm) if ns else nm

    def typeref_name(self, i):
        r = self.row(0x01, i)
        ns, nm = self.s(r[2]), self.s(r[1])
        return (ns + "." + nm) if ns else nm

    def tdor_name(self, v):
        tb, i = self.decode_coded("TypeDefOrRef", v)
        if not i:
            return ""
        if tb == 0x02:
            return self.typedef_name(i)
        if tb == 0x01:
            return self.typeref_name(i)
        return "TypeSpec#%d" % i

    def token_name(self, tok):
        tb, i = tok >> 24, tok & 0xFFFFFF
        try:
            if tb == 0x06:
                r = self.row(0x06, i)
                return "%s::%s" % (self.owner_of_method(i), self.s(r[3]))
            if tb == 0x0A:
                r = self.row(0x0A, i)
                ptb, pi = self.decode_coded("MemberRefParent", r[0])
                pn = self.typeref_name(pi) if ptb == 0x01 else (self.typedef_name(pi) if ptb == 0x02 else "?")
                return "%s::%s" % (pn, self.s(r[1]))
            if tb == 0x04:
                r = self.row(0x04, i)
                return "%s::%s" % (self.owner_of_field(i), self.s(r[1]))
            if tb == 0x02:
                return self.typedef_name(i)
            if tb == 0x01:
                return self.typeref_name(i)
            if tb == 0x1B:
                return "TypeSpec#%d" % i
            if tb == 0x2B:
                r = self.row(0x2B, i)
                mtb, mi = self.decode_coded("MethodDefOrRef", r[0])
                return self.token_name((mtb << 24) | mi) + "<...>"
        except Exception:
            pass
        return "tok(0x%08X)" % tok

    def owner_of_method(self, mi):
        if not hasattr(self, "_mowner"):
            self._mowner = {}
            n = self.nrows(0x02)
            for t in range(1, n + 1):
                a = self.row(0x02, t)[5]
                b = self.row(0x02, t + 1)[5] if t < n else self.nrows(0x06) + 1
                for k in range(a, b):
                    self._mowner[k] = t
        t = self._mowner.get(mi)
        return self.typedef_name(t) if t else "?"

    def owner_of_field(self, fi):
        if not hasattr(self, "_fowner"):
            self._fowner = {}
            n = self.nrows(0x02)
            for t in range(1, n + 1):
                a = self.row(0x02, t)[4]
                b = self.row(0x02, t + 1)[4] if t < n else self.nrows(0x04) + 1
                for k in range(a, b):
                    self._fowner[k] = t
        t = self._fowner.get(fi)
        return self.typedef_name(t) if t else "?"


# ---------------- signature decoding ----------------
PRIM = {0x01: "void", 0x02: "bool", 0x03: "char", 0x04: "sbyte", 0x05: "byte", 0x06: "short",
        0x07: "ushort", 0x08: "int", 0x09: "uint", 0x0A: "long", 0x0B: "ulong", 0x0C: "float",
        0x0D: "double", 0x0E: "string", 0x16: "TypedReference", 0x18: "IntPtr", 0x19: "UIntPtr",
        0x1C: "object"}


class SigReader:
    def __init__(self, m, data):
        self.m, self.d, self.p = m, data, 0

    def byte(self):
        v = self.d[self.p]
        self.p += 1
        return v

    def cint(self):
        b0 = self.byte()
        if (b0 & 0x80) == 0:
            return b0
        if (b0 & 0xC0) == 0x80:
            return ((b0 & 0x3F) << 8) | self.byte()
        return ((b0 & 0x1F) << 24) | (self.byte() << 16) | (self.byte() << 8) | self.byte()

    def type(self):
        if self.p >= len(self.d):
            return "?"
        e = self.byte()
        if e in PRIM:
            return PRIM[e]
        if e == 0x0F:
            return self.type() + "*"
        if e == 0x10:
            return "ref " + self.type()
        if e in (0x11, 0x12):
            return self.m.tdor_name(self.cint()) or "?"
        if e == 0x13:
            return "T%d" % self.cint()
        if e == 0x1E:
            return "M%d" % self.cint()
        if e == 0x1D:
            return self.type() + "[]"
        if e == 0x14:
            t = self.type()
            rank = self.cint()
            ns = self.cint()
            for _ in range(ns):
                self.cint()
            nl = self.cint()
            for _ in range(nl):
                self.cint()
            return t + "[" + "," * (rank - 1) + "]"
        if e == 0x15:
            base = self.type()
            n = self.cint()
            args = [self.type() for _ in range(n)]
            return "%s<%s>" % (base.split("`")[0], ", ".join(args))
        if e == 0x1F or e == 0x20:
            self.cint()
            return self.type()
        if e == 0x45:
            return self.type()
        if e == 0x1B:
            return "fnptr"
        if e == 0x01:
            return "void"
        return "e0x%02X" % e

    def method_sig(self):
        cc = self.byte()
        if cc & 0x10:
            self.cint()
        n = self.cint()
        ret = self.type()
        ps = []
        for _ in range(n):
            if self.p < len(self.d) and self.d[self.p] == 0x41:
                self.p += 1
            ps.append(self.type())
        return ret, ps, bool(cc & 0x20)

    def field_sig(self):
        self.byte()
        return self.type()

    def locals_sig(self):
        self.byte()
        n = self.cint()
        out = []
        for _ in range(n):
            while self.p < len(self.d) and self.d[self.p] in (0x1F, 0x20):
                self.byte()
                self.cint()
            if self.p < len(self.d) and self.d[self.p] == 0x16:
                self.byte()
                out.append("TypedReference")
                continue
            out.append(self.type())
        return out


# ---------------- IL opcodes ----------------
N, SV, VR, SI, I4, I8, R4, R8, SBR, BR, TOK, SW = range(12)
OPS = {}
for _c, _n in [(0x00, "nop"), (0x01, "break"), (0x14, "ldnull"), (0x15, "ldc.i4.m1"), (0x25, "dup"),
               (0x26, "pop"), (0x2A, "ret"), (0x58, "add"), (0x59, "sub"), (0x5A, "mul"), (0x5B, "div"),
               (0x5C, "div.un"), (0x5D, "rem"), (0x5E, "rem.un"), (0x5F, "and"), (0x60, "or"),
               (0x61, "xor"), (0x62, "shl"), (0x63, "shr"), (0x64, "shr.un"), (0x65, "neg"), (0x66, "not"),
               (0x67, "conv.i1"), (0x68, "conv.i2"), (0x69, "conv.i4"), (0x6A, "conv.i8"), (0x6B, "conv.r4"),
               (0x6C, "conv.r8"), (0x6D, "conv.u4"), (0x6E, "conv.u8"), (0x76, "conv.r.un"), (0x7A, "throw"),
               (0x8E, "ldlen"), (0x9B, "stelem.i"), (0x9C, "stelem.i1"), (0x9D, "stelem.i2"), (0x9E, "stelem.i4"),
               (0x9F, "stelem.i8"), (0xA0, "stelem.r4"), (0xA1, "stelem.r8"), (0xA2, "stelem.ref"),
               (0xC3, "ckfinite"), (0xD1, "conv.u2"), (0xD2, "conv.u1"), (0xD3, "conv.i"), (0xD4, "conv.ovf.i"),
               (0xD5, "conv.ovf.u"), (0xD6, "add.ovf"), (0xD7, "add.ovf.un"), (0xD8, "mul.ovf"),
               (0xD9, "mul.ovf.un"), (0xDA, "sub.ovf"), (0xDB, "sub.ovf.un"), (0xDC, "endfinally"),
               (0xDF, "stind.i"), (0xE0, "conv.u"), (0x51, "stind.ref"), (0x52, "stind.i1"), (0x53, "stind.i2"),
               (0x54, "stind.i4"), (0x55, "stind.i8"), (0x56, "stind.r4"), (0x57, "stind.r8")]:
    OPS[_c] = (_n, N)
for _i in range(4):
    OPS[0x02 + _i] = ("ldarg.%d" % _i, N)
    OPS[0x06 + _i] = ("ldloc.%d" % _i, N)
    OPS[0x0A + _i] = ("stloc.%d" % _i, N)
for _i in range(9):
    OPS[0x16 + _i] = ("ldc.i4.%d" % _i, N)
for _c, _n in [(0x0E, "ldarg.s"), (0x0F, "ldarga.s"), (0x10, "starg.s"), (0x11, "ldloc.s"),
               (0x12, "ldloca.s"), (0x13, "stloc.s")]:
    OPS[_c] = (_n, SV)
OPS[0x1F] = ("ldc.i4.s", SI)
OPS[0x20] = ("ldc.i4", I4)
OPS[0x21] = ("ldc.i8", I8)
OPS[0x22] = ("ldc.r4", R4)
OPS[0x23] = ("ldc.r8", R8)
for _c, _n in [(0x27, "jmp"), (0x28, "call"), (0x6F, "callvirt"), (0x73, "newobj"), (0x29, "calli")]:
    OPS[_c] = (_n, TOK)
for _c, _n in [(0x70, "cpobj"), (0x71, "ldobj"), (0x74, "castclass"), (0x75, "isinst"), (0x79, "unbox"),
               (0x81, "stobj"), (0x8C, "box"), (0x8D, "newarr"), (0x8F, "ldelema"), (0xA3, "ldelem"),
               (0xA4, "stelem"), (0xA5, "unbox.any"), (0xC2, "refanyval"), (0xC6, "mkrefany"),
               (0xD0, "ldtoken"), (0x7B, "ldfld"), (0x7C, "ldflda"), (0x7D, "stfld"), (0x7E, "ldsfld"),
               (0x7F, "ldsflda"), (0x80, "stsfld")]:
    OPS[_c] = (_n, TOK)
OPS[0x72] = ("ldstr", TOK)
for _i, _n in enumerate(["br", "brfalse", "brtrue", "beq", "bge", "bgt", "ble", "blt", "bne.un",
                         "bge.un", "bgt.un", "ble.un", "blt.un"]):
    OPS[0x2B + _i] = (_n + ".s", SBR)
    OPS[0x38 + _i] = (_n, BR)
OPS[0x45] = ("switch", SW)
for _i, _n in enumerate(["ldind.i1", "ldind.u1", "ldind.i2", "ldind.u2", "ldind.i4", "ldind.u4",
                         "ldind.i8", "ldind.i", "ldind.r4", "ldind.r8", "ldind.ref"]):
    OPS[0x46 + _i] = (_n, N)
for _i, _n in enumerate(["ldelem.i1", "ldelem.u1", "ldelem.i2", "ldelem.u2", "ldelem.i4", "ldelem.u4",
                         "ldelem.i8", "ldelem.i", "ldelem.r4", "ldelem.r8", "ldelem.ref"]):
    OPS[0x90 + _i] = (_n, N)
for _i, _n in enumerate(["conv.ovf.i1.un", "conv.ovf.i2.un", "conv.ovf.i4.un", "conv.ovf.i8.un",
                         "conv.ovf.u1.un", "conv.ovf.u2.un", "conv.ovf.u4.un", "conv.ovf.u8.un",
                         "conv.ovf.i.un", "conv.ovf.u.un"]):
    OPS[0x82 + _i] = (_n, N)
for _i, _n in enumerate(["conv.ovf.i1", "conv.ovf.u1", "conv.ovf.i2", "conv.ovf.u2", "conv.ovf.i4",
                         "conv.ovf.u4", "conv.ovf.i8", "conv.ovf.u8"]):
    OPS[0xB3 + _i] = (_n, N)
OPS[0xDD] = ("leave", BR)
OPS[0xDE] = ("leave.s", SBR)

OPS2 = {0x00: ("arglist", N), 0x01: ("ceq", N), 0x02: ("cgt", N), 0x03: ("cgt.un", N), 0x04: ("clt", N),
        0x05: ("clt.un", N), 0x06: ("ldftn", TOK), 0x07: ("ldvirtftn", TOK), 0x09: ("ldarg", VR),
        0x0A: ("ldarga", VR), 0x0B: ("starg", VR), 0x0C: ("ldloc", VR), 0x0D: ("ldloca", VR),
        0x0E: ("stloc", VR), 0x0F: ("localloc", N), 0x11: ("endfilter", N), 0x12: ("unaligned.", SV),
        0x13: ("volatile.", N), 0x14: ("tail.", N), 0x15: ("initobj", TOK), 0x16: ("constrained.", TOK),
        0x17: ("cpblk", N), 0x18: ("initblk", N), 0x1A: ("rethrow", N), 0x1C: ("sizeof", TOK),
        0x1D: ("refanytype", N), 0x1E: ("readonly.", N)}


def disasm(m, code, base_off):
    out = []
    i = 0
    n = len(code)
    while i < n:
        st = i
        b = code[i]
        i += 1
        if b == 0xFE:
            b2 = code[i]
            i += 1
            name, kind = OPS2.get(b2, ("unk.fe.%02X" % b2, N))
        else:
            name, kind = OPS.get(b, ("unk.%02X" % b, N))
        arg = ""
        if kind == N:
            pass
        elif kind == SV:
            arg = str(code[i])
            i += 1
        elif kind == SI:
            arg = str(struct.unpack_from("<b", code, i)[0])
            i += 1
        elif kind == VR:
            arg = str(struct.unpack_from("<H", code, i)[0])
            i += 2
        elif kind == I4:
            arg = str(struct.unpack_from("<i", code, i)[0])
            i += 4
        elif kind == I8:
            arg = str(struct.unpack_from("<q", code, i)[0])
            i += 8
        elif kind == R4:
            arg = str(struct.unpack_from("<f", code, i)[0])
            i += 4
        elif kind == R8:
            arg = str(struct.unpack_from("<d", code, i)[0])
            i += 8
        elif kind == SBR:
            d = struct.unpack_from("<b", code, i)[0]
            i += 1
            arg = "IL_%04X" % (i + d)
        elif kind == BR:
            d = struct.unpack_from("<i", code, i)[0]
            i += 4
            arg = "IL_%04X" % (i + d)
        elif kind == SW:
            cnt = struct.unpack_from("<I", code, i)[0]
            i += 4
            tg = []
            for _ in range(cnt):
                d = struct.unpack_from("<i", code, i)[0]
                i += 4
                tg.append(d)
            base = i
            arg = "(" + ", ".join("IL_%04X" % (base + d) for d in tg) + ")"
        elif kind == TOK:
            tok = struct.unpack_from("<I", code, i)[0]
            i += 4
            if name == "ldstr":
                try:
                    arg = '"%s"' % m.ustr(tok & 0xFFFFFF).replace("\n", "\\n").replace("\r", "\\r")
                except Exception:
                    arg = "str(0x%08X)" % tok
            else:
                arg = m.token_name(tok)
        out.append("    IL_%04X:  %-14s %s" % (st, name, arg))
    return out


TYPE_VIS = {0: "internal", 1: "public"}


def main(path, outdir):
    os.makedirs(outdir, exist_ok=True)
    buf = open(path, "rb").read()
    m = Meta(buf)

    # params per method
    nmeth = m.nrows(0x06)
    nparam = m.nrows(0x08)

    # custom attributes grouped by (table, row)
    ca = {}
    for i in range(1, m.nrows(0x0C) + 1):
        r = m.row(0x0C, i)
        ptb, pi = m.decode_coded("HasCustomAttribute", r[0])
        ctb, ci = m.decode_coded("CustomAttributeType", r[1])
        try:
            if ctb == 0x0A:
                rr = m.row(0x0A, ci)
                atb, ai = m.decode_coded("MemberRefParent", rr[0])
                aname = m.typeref_name(ai) if atb == 0x01 else m.typedef_name(ai)
                sig = m.blob(rr[2])
            else:
                rr = m.row(0x06, ci)
                aname = m.owner_of_method(ci)
                sig = m.blob(rr[4])
        except Exception:
            aname, sig = "?", b""
        ca.setdefault((ptb, pi), []).append((aname, m.blob(r[2]) if r[2] else b"", sig))

    # interfaces
    ifaces = {}
    for i in range(1, m.nrows(0x09) + 1):
        r = m.row(0x09, i)
        ifaces.setdefault(r[0], []).append(m.tdor_name(r[1]))

    lines = []
    ntd = m.nrows(0x02)
    for t in range(1, ntd + 1):
        r = m.row(0x02, t)
        flags, name, ns = r[0], m.s(r[1]), m.s(r[2])
        base = m.tdor_name(r[3])
        full = (ns + "." + name) if ns else name
        lines.append("\n" + "=" * 78)
        lines.append("TYPE  %s" % full)
        lines.append("  flags   : 0x%08X" % flags)
        lines.append("  extends : %s" % base)
        if t in ifaces:
            lines.append("  implements: %s" % ", ".join(ifaces[t]))
        for (an, val, sg) in ca.get((0x02, t), []):
            lines.append("  [attr] %s  blob=%s" % (an, val.hex()))
        # fields
        fa = r[4]
        fb = m.row(0x02, t + 1)[4] if t < ntd else m.nrows(0x04) + 1
        for f in range(fa, fb):
            fr = m.row(0x04, f)
            try:
                ft = SigReader(m, m.blob(fr[2])).field_sig()
            except Exception:
                ft = "?"
            lines.append("  FIELD 0x%04X %s %s" % (fr[0], ft, m.s(fr[1])))
        # methods
        ma = r[5]
        mb = m.row(0x02, t + 1)[5] if t < ntd else nmeth + 1
        for k in range(ma, mb):
            mr = m.row(0x06, k)
            mname = m.s(mr[3])
            try:
                ret, ps, inst = SigReader(m, m.blob(mr[4])).method_sig()
            except Exception:
                ret, ps, inst = "?", [], True
            pa = mr[5]
            pb = m.row(0x06, k + 1)[5] if k < nmeth else nparam + 1
            pnames = []
            for pidx in range(pa, pb):
                pr = m.row(0x08, pidx)
                if pr[1] > 0:
                    pnames.append(m.s(pr[2]))
            while len(pnames) < len(ps):
                pnames.append("arg%d" % (len(pnames) + 1))
            sigtxt = ", ".join("%s %s" % (a, b) for a, b in zip(ps, pnames))
            lines.append("\n  METHOD 0x%04X %s %s(%s)   %s" % (mr[2], ret, mname, sigtxt, "instance" if inst else "static"))
            for (an, val, sg) in ca.get((0x06, k), []):
                lines.append("    [attr] %s blob=%s" % (an, val.hex()))
            rva = mr[0]
            if not rva:
                lines.append("    <no body>")
                continue
            off = rva_to_off(rva, m.secs)
            b0 = buf[off]
            if (b0 & 3) == 2:
                size = b0 >> 2
                code = buf[off + 1:off + 1 + size]
                locs = []
            else:
                fl = struct.unpack_from("<H", buf, off)[0]
                hsz = (fl >> 12) * 4
                size = struct.unpack_from("<I", buf, off + 4)[0]
                lvt = struct.unpack_from("<I", buf, off + 8)[0]
                code = buf[off + hsz:off + hsz + size]
                locs = []
                if lvt:
                    try:
                        locs = SigReader(m, m.blob(m.row(0x11, lvt & 0xFFFFFF)[0])).locals_sig()
                    except Exception:
                        locs = []
                if fl & 0x08:
                    sp = off + hsz + size
                    sp = (sp + 3) & ~3
                    while True:
                        kind = buf[sp]
                        if kind & 0x40:
                            dsz = int.from_bytes(buf[sp + 1:sp + 4], "little")
                            cnt = (dsz - 4) // 24
                            q = sp + 4
                            for _ in range(cnt):
                                ef, tro, trl, hro, hrl, ct = struct.unpack_from("<IIIIII", buf, q)
                                lines.append("    .try IL_%04X..IL_%04X %s IL_%04X..IL_%04X %s" % (
                                    tro, tro + trl, ["catch", "filter", "finally", "fault"][ef if ef < 4 else 0],
                                    hro, hro + hrl, m.token_name(ct) if ef == 0 else ""))
                                q += 24
                        else:
                            dsz = buf[sp + 1]
                            cnt = (dsz - 4) // 12
                            q = sp + 4
                            for _ in range(cnt):
                                ef, tro, trl, hro, hrl = struct.unpack_from("<HHBHB", buf, q)
                                ct = struct.unpack_from("<I", buf, q + 8)[0]
                                lines.append("    .try IL_%04X..IL_%04X %s IL_%04X..IL_%04X %s" % (
                                    tro, tro + trl, ["catch", "filter", "finally", "fault"][ef if ef < 4 else 0],
                                    hro, hro + hrl, m.token_name(ct) if ef == 0 else ""))
                                q += 12
                        if not (kind & 0x80):
                            break
                        sp += dsz
            if locs:
                lines.append("    .locals (%s)" % ", ".join("[%d] %s" % (i2, x) for i2, x in enumerate(locs)))
            lines.extend(disasm(m, code, off))

    txt = "\n".join(lines)
    open(os.path.join(outdir, "disassembly.txt"), "w", encoding="utf-8").write(txt)
    print("wrote %d lines" % len(lines))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
