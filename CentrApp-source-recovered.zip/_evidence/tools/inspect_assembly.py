#!/usr/bin/env python3
"""Inventory a .NET assembly: types, methods, IL presence, string literals.

Pure-Python CLI metadata reader (ECMA-335). No .NET tooling required.
"""
import os
import re
import struct
import sys


def sections_and_dd(buf):
    e_lfanew = struct.unpack_from("<I", buf, 0x3C)[0]
    coff = e_lfanew + 4
    num_sections = struct.unpack_from("<H", buf, coff + 2)[0]
    size_opt = struct.unpack_from("<H", buf, coff + 16)[0]
    opt = coff + 20
    magic = struct.unpack_from("<H", buf, opt)[0]
    dd = opt + (96 if magic == 0x10B else 112)
    sec_off = opt + size_opt
    secs = []
    for i in range(num_sections):
        s = sec_off + i * 40
        vsize, vaddr, rsize, praw = struct.unpack_from("<IIII", buf, s + 8)
        secs.append((vaddr, vsize, praw, rsize))
    return dd, secs


def rva_to_off(rva, secs):
    for (vaddr, vsize, praw, rsize) in secs:
        if vaddr <= rva < vaddr + max(vsize, rsize):
            return praw + (rva - vaddr)
    return None


class Meta:
    def __init__(self, buf):
        self.buf = buf
        dd, secs = sections_and_dd(buf)
        self.secs = secs
        cli_rva = struct.unpack_from("<I", buf, dd + 14 * 8)[0]
        cli = rva_to_off(cli_rva, secs)
        self.cli_off = cli
        md_rva = struct.unpack_from("<I", buf, cli + 8)[0]
        self.res_rva, self.res_size = struct.unpack_from("<II", buf, cli + 24)
        md = rva_to_off(md_rva, secs)
        self.md = md
        ver_len = struct.unpack_from("<I", buf, md + 12)[0]
        self.runtime_version = buf[md + 16:md + 16 + ver_len].split(b"\0")[0].decode("ascii", "replace")
        p = md + 16 + ver_len + 2
        n = struct.unpack_from("<H", buf, p)[0]
        p += 2
        self.streams = {}
        for _ in range(n):
            soff, ssize = struct.unpack_from("<II", buf, p)
            p += 8
            e = buf.index(b"\0", p)
            self.streams[buf[p:e].decode("ascii", "replace")] = (md + soff, ssize)
            p = (e + 1 + 3) & ~3
        self.tstream = self.streams.get("#~") or self.streams.get("#-")
        self.stroff = self.streams.get("#Strings", (0, 0))[0]
        self.us = self.streams.get("#US")
        self._read_tables()

    def s(self, idx):
        e = self.buf.index(b"\0", self.stroff + idx)
        return self.buf[self.stroff + idx:e].decode("utf-8", "replace")

    def _read_tables(self):
        buf, toff = self.buf, self.tstream[0]
        self.heap_sizes = buf[toff + 6]
        valid = struct.unpack_from("<Q", buf, toff + 8)[0]
        q = toff + 24
        self.rows = {}
        for i in range(64):
            if (valid >> i) & 1:
                self.rows[i] = struct.unpack_from("<I", buf, q)[0]
                q += 4
        self.tables_start = q
        self.S = 4 if self.heap_sizes & 1 else 2
        self.G = 4 if self.heap_sizes & 2 else 2
        self.B = 4 if self.heap_sizes & 4 else 2

    def idx(self, table):
        return 4 if self.rows.get(table, 0) >= 65536 else 2

    def coded(self, tables, bits):
        m = max((self.rows.get(t, 0) for t in tables), default=0)
        return 4 if m >= (1 << (16 - bits)) else 2

    def row_size(self, t):
        S, G, B = self.S, self.G, self.B
        if t == 0x00:
            return 2 + S + 3 * G
        if t == 0x01:
            return self.coded([0x00, 0x1A, 0x23, 0x01], 2) + 2 * S
        if t == 0x02:
            return 4 + 2 * S + self.coded([0x02, 0x01, 0x1B], 2) + self.idx(0x04) + self.idx(0x06)
        if t == 0x03:
            return self.idx(0x04)
        if t == 0x04:
            return 2 + S + B
        if t == 0x05:
            return self.idx(0x06)
        if t == 0x06:
            return 4 + 2 + 2 + S + B + self.idx(0x08)
        raise KeyError(t)

    def table_offset(self, t):
        off = self.tables_start
        for i in range(t):
            if i in self.rows:
                off += self.rows[i] * self.row_size(i)
        return off

    def read_idx(self, off, size):
        return struct.unpack_from("<I" if size == 4 else "<H", self.buf, off)[0]

    def typedefs(self):
        t = 0x02
        base = self.table_offset(t)
        rs = self.row_size(t)
        ext = self.coded([0x02, 0x01, 0x1B], 2)
        out = []
        for i in range(self.rows.get(t, 0)):
            o = base + i * rs
            flags = struct.unpack_from("<I", self.buf, o)[0]
            name = self.s(self.read_idx(o + 4, self.S))
            ns = self.s(self.read_idx(o + 4 + self.S, self.S))
            mlist = self.read_idx(o + 4 + 2 * self.S + ext + self.idx(0x04), self.idx(0x06))
            out.append({"flags": flags, "name": name, "ns": ns, "mlist": mlist})
        return out

    def methoddefs(self):
        t = 0x06
        base = self.table_offset(t)
        rs = self.row_size(t)
        out = []
        for i in range(self.rows.get(t, 0)):
            o = base + i * rs
            rva = struct.unpack_from("<I", self.buf, o)[0]
            impl = struct.unpack_from("<H", self.buf, o + 4)[0]
            flags = struct.unpack_from("<H", self.buf, o + 6)[0]
            name = self.s(self.read_idx(o + 8, self.S))
            out.append({"rva": rva, "impl": impl, "flags": flags, "name": name})
        return out

    def user_strings(self):
        if not self.us:
            return []
        off, size = self.us
        buf = self.buf
        p, end, out = off + 1, off + size, []
        while p < end:
            b0 = buf[p]
            if (b0 & 0x80) == 0:
                ln, p = b0, p + 1
            elif (b0 & 0xC0) == 0x80:
                ln, p = ((b0 & 0x3F) << 8) | buf[p + 1], p + 2
            else:
                ln = ((b0 & 0x1F) << 24) | (buf[p + 1] << 16) | (buf[p + 2] << 8) | buf[p + 3]
                p += 4
            if ln <= 0 or p + ln > end:
                break
            raw = buf[p:p + ln - 1] if ln % 2 == 1 else buf[p:p + ln]
            p += ln
            try:
                sv = raw.decode("utf-16-le", "replace").strip()
            except Exception:
                sv = ""
            if sv:
                out.append(sv)
        return out


METHOD_ABSTRACT = 0x0400
METHOD_PINVOKE = 0x2000


def main(path, outdir):
    os.makedirs(outdir, exist_ok=True)
    buf = open(path, "rb").read()
    m = Meta(buf)
    tds, mds = m.typedefs(), m.methoddefs()

    bodied = sum(1 for d in mds if d["rva"])
    abstract = sum(1 for d in mds if d["flags"] & METHOD_ABSTRACT)
    pinvoke = sum(1 for d in mds if d["flags"] & METHOD_PINVOKE)
    missing = [d for d in mds if not d["rva"] and not (d["flags"] & (METHOD_ABSTRACT | METHOD_PINVOKE))]

    lines = []
    lines.append("assembly : %s" % os.path.basename(path))
    lines.append("size     : %d bytes" % len(buf))
    lines.append("runtime  : %s" % m.runtime_version)
    lines.append("types    : %d" % len(tds))
    lines.append("methods  : %d" % len(mds))
    lines.append("  with IL body      : %d" % bodied)
    lines.append("  abstract/iface    : %d" % abstract)
    lines.append("  p/invoke          : %d" % pinvoke)
    lines.append("  BODY MISSING      : %d  <-- IL stripped if large" % len(missing))
    lines.append("managed resources : rva=%d size=%d" % (m.res_rva, m.res_size))
    summary = "\n".join(lines)
    print(summary)
    open(os.path.join(outdir, "summary.txt"), "w", encoding="utf-8").write(summary + "\n")

    # types + methods listing
    total = len(mds)
    rep = []
    for i, td in enumerate(tds):
        start = td["mlist"]
        stop = tds[i + 1]["mlist"] if i + 1 < len(tds) else total + 1
        full = (td["ns"] + "." + td["name"]) if td["ns"] else td["name"]
        rep.append("\n%s" % full)
        for k in range(start, stop):
            if 1 <= k <= total:
                d = mds[k - 1]
                mark = "IL" if d["rva"] else ("abs" if d["flags"] & METHOD_ABSTRACT else ("pinv" if d["flags"] & METHOD_PINVOKE else "NOBODY"))
                rep.append("    [%-6s] %s" % (mark, d["name"]))
    open(os.path.join(outdir, "types_and_methods.txt"), "w", encoding="utf-8").write("\n".join(rep) + "\n")

    # app-owned types only (skip compiler/framework noise)
    app = [t for t in tds if not t["name"].startswith("<") and "PrivateImplementationDetails" not in t["name"]]
    open(os.path.join(outdir, "types_list.txt"), "w", encoding="utf-8").write(
        "\n".join(sorted(((t["ns"] + "." + t["name"]) if t["ns"] else t["name"]) for t in app)) + "\n")

    # string literals
    us = m.user_strings()
    open(os.path.join(outdir, "strings.txt"), "w", encoding="utf-8").write("\n".join(us) + "\n")
    urls = sorted(set(re.findall(r"https?://[^\s\"'<>]+", "\n".join(us))))
    open(os.path.join(outdir, "urls.txt"), "w", encoding="utf-8").write("\n".join(urls) + "\n")
    print("\nstring literals: %d, urls: %d" % (len(us), len(urls)))
    for u in urls[:25]:
        print("   ", u)

    # embedded managed resources blob
    if m.res_rva:
        ro = rva_to_off(m.res_rva, m.secs)
        if ro is not None:
            open(os.path.join(outdir, "managed_resources.bin"), "wb").write(buf[ro:ro + m.res_size])

    # scan for embedded XAML
    xml_hits = [mm.start() for mm in re.finditer(rb"<\?xml", buf)]
    print("xaml/xml markers in assembly:", len(xml_hits))
    if xml_hits:
        xd = os.path.join(outdir, "xaml")
        os.makedirs(xd, exist_ok=True)
        for n, st in enumerate(xml_hits[:60]):
            seg = buf[st:st + 200000]
            end = seg.rfind(b">")
            open(os.path.join(xd, "fragment_%02d.xml" % n), "wb").write(seg[:end + 1] if end > 0 else seg[:8000])


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
