using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Networking;
using Microsoft.Maui.Storage;

namespace CentrApp;

public partial class MainPage : ContentPage
{
    private const string SiteUrl = "https://okp-center.gt.tc";

    private bool _showingOffline;
    private bool _loaded;

    public MainPage()
    {
        InitializeComponent();

        Connectivity.Current.ConnectivityChanged += OnConnectivityChanged;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        if (_loaded)
            return;

        _loaded = true;
        LoadAppropriate();
    }

    private void OnConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
    {
        if (e.NetworkAccess == NetworkAccess.Internet && _showingOffline)
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                _showingOffline = false;
                Web.Source = SiteUrl;
            });
        }
    }

    private void LoadAppropriate()
    {
        if (Connectivity.Current.NetworkAccess == NetworkAccess.Internet)
        {
            _showingOffline = false;
            Web.Source = SiteUrl;
        }
        else
        {
            _ = ShowOfflineAsync();
        }
    }

    private async Task ShowOfflineAsync()
    {
        _showingOffline = true;

        try
        {
            using var stream = await FileSystem.OpenAppPackageFileAsync("offline.html");
            using var reader = new StreamReader(stream);
            var html = await reader.ReadToEndAsync();

            Web.Source = new HtmlWebViewSource { Html = html };
        }
        catch
        {
            Web.Source = new HtmlWebViewSource
            {
                Html = "<html><body style='background:#111b21;color:#e9edef;font-family:sans-serif;text-align:center;padding-top:40vh'><h2>\u041d\u0435\u0442 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f \u043a \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442\u0443</h2></body></html>"
            };
        }
    }
}
