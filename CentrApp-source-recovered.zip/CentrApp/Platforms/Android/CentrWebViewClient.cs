using Android.Content;
using Android.Webkit;

namespace CentrApp;

public class CentrWebViewClient : WebViewClient
{
    private const string Domain = "okp-center.gt.tc";

    public const string OfflineAsset = "file:///android_asset/offline.html";

    public override bool ShouldOverrideUrlLoading(WebView? view, IWebResourceRequest? request)
    {
        var url = request?.Url?.ToString();

        if (string.IsNullOrEmpty(url) || view is null)
            return false;

        if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
            url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            if (url.Contains(Domain, StringComparison.OrdinalIgnoreCase))
                return false;

            return OpenExternally(url);
        }

        return OpenExternally(url);
    }

    public override void OnPageFinished(WebView? view, string? url)
    {
        base.OnPageFinished(view, url);

        PushManager.InjectTokenIfAvailable(view);
    }

    public override void OnReceivedError(WebView? view, IWebResourceRequest? request, WebResourceError? error)
    {
        if (view is not null && request is not null && request.IsForMainFrame)
        {
            view.LoadUrl(OfflineAsset);
            return;
        }

        base.OnReceivedError(view, request, error);
    }

    private static bool OpenExternally(string url)
    {
        try
        {
            var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse(url));
            intent.AddFlags(ActivityFlags.NewTask);
            Android.App.Application.Context.StartActivity(intent);
        }
        catch
        {
        }

        return true;
    }
}
