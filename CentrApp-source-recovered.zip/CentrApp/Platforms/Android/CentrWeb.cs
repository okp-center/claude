using Android.Webkit;

namespace CentrApp;

public static class CentrWeb
{
    public static WebView? Platform { get; set; }
}
