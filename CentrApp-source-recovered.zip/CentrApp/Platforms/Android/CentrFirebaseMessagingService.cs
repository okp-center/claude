using Android.App;
using Firebase.Messaging;

namespace CentrApp;

[Service(Exported = false)]
[IntentFilter(new[] { "com.google.firebase.MESSAGING_EVENT" })]
public class CentrFirebaseMessagingService : FirebaseMessagingService
{
    public override void OnNewToken(string token)
    {
        base.OnNewToken(token);

        PushManager.SetToken(token);
    }

    public override void OnMessageReceived(RemoteMessage message)
    {
        base.OnMessageReceived(message);

        var title = message.GetNotification()?.Title;
        var body = message.GetNotification()?.Body;
        string? url = null;

        var data = message.Data;
        if (data is not null)
        {
            if (string.IsNullOrEmpty(title) && data.TryGetValue("title", out var dataTitle))
                title = dataTitle;

            if (string.IsNullOrEmpty(body) && data.TryGetValue("body", out var dataBody))
                body = dataBody;

            data.TryGetValue("url", out url);
        }

        PushManager.ShowMessageNotification(this, title, body, url);
    }
}
