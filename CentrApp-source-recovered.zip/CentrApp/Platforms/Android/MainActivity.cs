using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Firebase;

namespace CentrApp;

[Activity(
    Theme = "@style/Maui.SplashTheme",
    MainLauncher = true,
    LaunchMode = LaunchMode.SingleTop,
    ConfigurationChanges = ConfigChanges.ScreenSize
        | ConfigChanges.Orientation
        | ConfigChanges.UiMode
        | ConfigChanges.ScreenLayout
        | ConfigChanges.SmallestScreenSize
        | ConfigChanges.Density)]
public class MainActivity : MauiAppCompatActivity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);

        try
        {
            FirebaseApp.InitializeApp(this);
        }
        catch
        {
        }

        PushManager.EnsureChannel(this);
        RequestStartupPermissions();
        PushManager.FetchToken();
    }

    protected override void OnNewIntent(Intent? intent)
    {
        base.OnNewIntent(intent);

        Intent = intent;
    }

    private void RequestStartupPermissions()
    {
        var wanted = new List<string>
        {
            "android.permission.RECORD_AUDIO",
            "android.permission.CAMERA"
        };

        if (Build.VERSION.SdkInt >= BuildVersionCodes.Tiramisu)
            wanted.Add("android.permission.POST_NOTIFICATIONS");

        var missing = new List<string>();

        foreach (var permission in wanted)
        {
            if (CheckSelfPermission(permission) != Permission.Granted)
                missing.Add(permission);
        }

        if (missing.Count > 0)
            RequestPermissions(missing.ToArray(), 1001);
    }

    public override void OnBackPressed()
    {
        var web = CentrWeb.Platform;

        if (web is not null && web.CanGoBack())
        {
            web.GoBack();
            return;
        }

        base.OnBackPressed();
    }

    protected override void OnActivityResult(int requestCode, Result resultCode, Intent? data)
    {
        base.OnActivityResult(requestCode, resultCode, data);

        if (requestCode == FileChooserBridge.RequestCode)
            FileChooserBridge.Deliver(resultCode, data);
    }
}
