using Android.App;
using Android.Content;
using Android.OS;
using Android.Webkit;
using AndroidX.Core.App;
using Firebase.Messaging;
using Microsoft.Maui.ApplicationModel;

namespace CentrApp;

public static class PushManager
{
    public const string ChannelId = "centr_messages";

    public static string? Token { get; private set; }

    public static void EnsureChannel(Context context)
    {
        if (Build.VERSION.SdkInt < BuildVersionCodes.O)
            return;

        if (context.GetSystemService(Context.NotificationService) is not NotificationManager manager)
            return;

        if (manager.GetNotificationChannel(ChannelId) is not null)
            return;

        var channel = new NotificationChannel(ChannelId, "\u0421\u043e\u043e\u0431\u0449\u0435\u043d\u0438\u044f \u0426\u0435\u043d\u0442\u0440", NotificationImportance.High)
        {
            Description = "\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f \u043e \u043d\u043e\u0432\u044b\u0445 \u0441\u043e\u043e\u0431\u0449\u0435\u043d\u0438\u044f\u0445 \u0432 \u0426\u0435\u043d\u0442\u0440\u0435"
        };

        channel.EnableVibration(true);

        manager.CreateNotificationChannel(channel);
    }

    public static void FetchToken()
    {
        try
        {
            FirebaseMessaging.Instance.GetToken().AddOnCompleteListener(new TokenCompleteListener());
        }
        catch
        {
        }
    }

    public static void SetToken(string? token)
    {
        if (string.IsNullOrEmpty(token))
            return;

        Token = token;

        var view = CentrWeb.Platform;

        if (view is not null)
            MainThread.BeginInvokeOnMainThread(() => InjectTokenIfAvailable(view));
    }

    public static void InjectTokenIfAvailable(WebView? view)
    {
        if (view is null || string.IsNullOrEmpty(Token))
            return;

        var safe = Token.Replace("\\", "\\\\").Replace("'", "\\'");

        try
        {
            view.EvaluateJavascript("window.centrOnPushToken && window.centrOnPushToken('" + safe + "','android');", null);
        }
        catch
        {
        }
    }

    public static void ShowMessageNotification(Context context, string? title, string? body, string? url)
    {
        EnsureChannel(context);

        var intent = new Intent(context, typeof(MainActivity));
        intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.SingleTop);

        if (!string.IsNullOrEmpty(url))
            intent.PutExtra("centr_url", url);

        var flags = PendingIntentFlags.UpdateCurrent;

        if (Build.VERSION.SdkInt >= BuildVersionCodes.S)
            flags |= PendingIntentFlags.Immutable;

        var pending = PendingIntent.GetActivity(context, 100, intent, flags);

        var builder = new NotificationCompat.Builder(context, ChannelId)
            .SetContentTitle(string.IsNullOrEmpty(title) ? "\u0426\u0435\u043d\u0442\u0440" : title)
            .SetContentText(string.IsNullOrEmpty(body) ? "\u041d\u043e\u0432\u043e\u0435 \u0441\u043e\u043e\u0431\u0449\u0435\u043d\u0438\u0435" : body)
            .SetSmallIcon(Resource.Drawable.ic_notification)
            .SetAutoCancel(true)
            .SetPriority(1)   // NotificationCompat.PriorityHigh
            .SetDefaults(-1)  // NotificationCompat.DefaultAll
            .SetContentIntent(pending);

        NotificationManagerCompat.From(context).Notify(new Random().Next(1, 1000000), builder.Build());
    }
}
