using Android.Content;
using Android.OS;
using Android.Webkit;

namespace CentrApp;

public class CentrWebChromeClient : WebChromeClient
{
    public override void OnPermissionRequest(PermissionRequest? request)
    {
        try
        {
            if (request is not null)
                request.Grant(request.GetResources());
        }
        catch
        {
            base.OnPermissionRequest(request);
        }
    }

    public override bool OnShowFileChooser(WebView? webView, IValueCallback? filePathCallback, FileChooserParams? fileChooserParams)
    {
        return FileChooserBridge.Start(filePathCallback, fileChooserParams);
    }

    public override bool OnCreateWindow(WebView? view, bool isDialog, bool isUserGesture, Message? resultMsg)
    {
        try
        {
            var url = view?.GetHitTestResult()?.Extra;

            if (!string.IsNullOrEmpty(url))
            {
                var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse(url));
                intent.AddFlags(ActivityFlags.NewTask);
                Android.App.Application.Context.StartActivity(intent);
            }
        }
        catch
        {
        }

        return false;
    }
}
