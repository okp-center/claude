using Android.App;
using Android.Content;
using Android.Webkit;

namespace CentrApp;

public static class FileChooserBridge
{
    public const int RequestCode = 51426;

    private static IValueCallback? _callback;

    public static bool Start(IValueCallback? callback, WebChromeClient.FileChooserParams? prms)
    {
        var activity = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity;

        if (activity is null || prms is null)
        {
            callback?.OnReceiveValue(null);
            return false;
        }

        _callback?.OnReceiveValue(null);
        _callback = callback;

        try
        {
            var intent = prms.CreateIntent();
            activity.StartActivityForResult(intent, RequestCode);
            return true;
        }
        catch
        {
            _callback = null;
            callback?.OnReceiveValue(null);
            return false;
        }
    }

    public static void Deliver(Result resultCode, Intent? data)
    {
        var uris = WebChromeClient.FileChooserParams.ParseResult((int)resultCode, data);

        _callback?.OnReceiveValue(uris);
        _callback = null;
    }
}
