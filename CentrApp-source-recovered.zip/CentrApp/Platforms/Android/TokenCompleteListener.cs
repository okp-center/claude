using Android.Gms.Tasks;

namespace CentrApp;

internal class TokenCompleteListener : Java.Lang.Object, IOnCompleteListener
{
    public void OnComplete(Android.Gms.Tasks.Task task)
    {
        try
        {
            if (task.IsSuccessful && task.Result is not null)
                PushManager.SetToken(task.Result.ToString());
        }
        catch
        {
        }
    }
}
