using Microsoft.Maui.Handlers;

namespace CentrApp;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();

#if ANDROID
        WebViewHandler.Mapper.AppendToMapping("CentrAndroidWebView", (handler, view) =>
        {
            var platform = handler.PlatformView;
            if (platform is null)
                return;

            var settings = platform.Settings;
            settings.JavaScriptEnabled = true;
            settings.DomStorageEnabled = true;
            settings.DatabaseEnabled = true;
            settings.MediaPlaybackRequiresUserGesture = false;
            settings.AllowFileAccess = true;
            settings.AllowContentAccess = true;
            settings.JavaScriptCanOpenWindowsAutomatically = true;
            settings.SetSupportMultipleWindows(true);

            platform.SetWebViewClient(new CentrWebViewClient());
            platform.SetWebChromeClient(new CentrWebChromeClient());

            CentrWeb.Platform = platform;
            PushManager.InjectTokenIfAvailable(platform);
        });
#endif

        return builder.Build();
    }
}
